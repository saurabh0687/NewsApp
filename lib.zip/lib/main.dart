import 'package:flutter/material.dart';
import 'package:news/pages/News.dart';

void main()
{
  runApp(MaterialApp(
    home:NewsApp()
  ));
}