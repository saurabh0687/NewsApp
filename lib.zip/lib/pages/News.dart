import 'package:carousel_slider/carousel_options.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:news/model/model.dart';
import 'package:news/service/newsService.dart';
import 'package:news/widget/article.dart';

class NewsApp extends StatefulWidget {
  const NewsApp({super.key});

  @override
  State<NewsApp> createState() => _NewsAppState();
}

class _NewsAppState extends State<NewsApp> {
   NewsService service= NewsService();
   List<NewsData> news=[];
   @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future<List<NewsData>> future= service.getNews();
    future.then((List<NewsData> news){
      this.news=news;
      setState(() {
        
      });
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
       title: Text("News"),
       leading: Icon(Icons.menu),
       backgroundColor: Colors.blue,
       centerTitle: true,
       actions: [
        Padding(padding: EdgeInsets.all(10
      ),
      child:Icon(Icons.notifications) ,)
       ],
       
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(top:5),
              child: TextField(
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.search),
                ),
                onSubmitted: (value) {
                  print(value);
                },
                
              ),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                border: Border.all(color: Colors.black),
                borderRadius: BorderRadius.circular(10),
                
              ),
              
            ),
           Container(
              margin: EdgeInsets.only(top: 10),
              child: Image.network("https://media.istockphoto.com/id/1197831888/vector/male-hand-holding-megaphone-with-breaking-news-speech-bubble-loudspeaker-banner-for-business.jpg?s=612x612&w=0&k=20&c=4CvdND_C8H3AxDMlEAZ8j9oagSvlmMcNHlrVoqoc9KQ="),
            ),
            Wrap(
              children: news.map((e) => Articles(text: e.headNews, url:e.newsImage)).toList()
            )
          ],
        ),
      ),
    );
  }
}