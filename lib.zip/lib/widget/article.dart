import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Articles extends StatelessWidget {
  late String url;
  late String text;
  Articles({required this.text,required this.url});


  @override
  Widget build(BuildContext context) {
    return  Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)
                  ),
                  elevation: 15.0,
                  child: Stack(
                    children: [
             ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: Image.network(url)),
                  Positioned(left: 0,
                  right: 0,
                  bottom: 0,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        gradient: LinearGradient(colors:[ Color.fromARGB(255, 23, 3, 86).withOpacity(0),Color.fromARGB(230, 9, 36, 67)],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        )
                      ),
                      margin: EdgeInsets.symmetric(horizontal: 2,vertical: 2),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(text, style: TextStyle(
                          color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18,
                                    ),),
                                 
                        ],
                      ),
                    ))
                    ],
                  ),
             );
     
   
  }
}