class NewsData
{
   late String headNews;

   late String newsImage;
   late String newsDesc;
  NewsData(
    {required this.headNews,required this.newsImage, required this.newsDesc}
  );
  static NewsData fromJSON(dynamic map)
  {
    return NewsData(headNews: map['title'], newsImage: map['urlToImage']??'https://thumbs.dreamstime.com/b/news-newspapers-folded-stacked-word-wooden-block-puzzle-dice-concept-newspaper-media-press-release-42301371.jpg', newsDesc: map['description']);
  }

}