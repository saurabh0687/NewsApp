import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:news/infra/apiClient.dart';
import 'package:news/model/model.dart';

class NewsService
{
  ApiClient apiClient= ApiClient();
  Future<List<NewsData>> getNews() async
  {
    Response response= await apiClient.get("https://newsapi.org/v2/everything?domains=wsj.com&apiKey=a69f71b1fa0c40f7aeb60c862becfaa8");
    //print(response.data);
    //print(response.data.runtimeType);
   // List<dynamic> list= response.data;
    List<dynamic> list=response.data["articles"];
    List<NewsData> newdata=list.map((e) => NewsData.fromJSON(e)).toList();
    return newdata;
  }
}